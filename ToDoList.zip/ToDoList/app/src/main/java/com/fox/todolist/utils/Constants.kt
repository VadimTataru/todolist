package com.fox.todolist.utils

object Constants {
    const val CHECK_TAG = "just_checking"
}